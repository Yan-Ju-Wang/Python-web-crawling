import bmi

print(bmi.__name__)