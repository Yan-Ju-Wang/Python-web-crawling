from bmi import *
print(max)
print(bmi(65, 1.75))
pro = Profile('Ryan', '18')
pro.showProfile()